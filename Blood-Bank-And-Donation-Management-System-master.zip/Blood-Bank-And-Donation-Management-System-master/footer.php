<html>
<head>
  <style>
  #footer {

  position:absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 75px;
  background-color:#000000;
  color:white;
  text-align: center;
}
  </style>
</head>
<body>
  <div id="footer" >
  <b><center>Created by Suraj Patil<br>
  Blood Bank & Donation Management
  <br>
  ****_____****
  </center>
  </div>


</body>

</html>
